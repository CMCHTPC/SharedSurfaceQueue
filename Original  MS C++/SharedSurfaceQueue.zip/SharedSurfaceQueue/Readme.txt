D3D9Ex and DXGI Interop Sample
===============================
This is a utility to make interop between D3D9Ex and DXGI easier.  It also includes a sample on how to use the utility.

 
Sample Language Implementations
===============================
     This sample is available in C++.

Files
===============================
* SurfaceQueueLib\*: Contains code for the utility library
* SurfaceQueueSample\DirectX.bmp: Texture map for the sample.
* SurfaceQueueSample\TextureMap.fx: Effect file for the sample.
* SurfaceQueueSample\SharedSurfaceSample.cpp: Code for the sample.
 
 
Prerequisites
===============================
Microsoft Windows� 7 or Microsoft Windows� Vista
August 2009 DirectX SDK

Updates
===============================
(Feburary 2010) - Minor updates
    1) Fixed library to compile without warnings with /w4 enabled on VS2008
    2) Added compile time #define to better control exception throwing on memory allocations
    3) Added IDXGISurface as a possible Dequeue type for DX10/11 consumers.
