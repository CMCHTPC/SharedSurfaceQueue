// THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
// ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
// THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
// PARTICULAR PURPOSE.
//
// Copyright (c) Microsoft Corporation. All rights reserved

// Windows Header Files:
#include <windows.h>

// C RunTime Header Files
#include <stdlib.h>
#include <stdio.h>

#include "SurfaceQueue.h"
#include "d3d9.h"
#include "d3dx9.h"
#include "D3D10_1.h"
#include "d3dx10.h"

#define WIDTH 640
#define HEIGHT 480

#define TEXTURE_PATH "..\\SurfaceQueueSample\\DirectX.bmp"
#define EFFECT_PATH "..\\SurfaceQueueSample\\TextureMap.fx"

#define SAFE_RELEASE(x) if(x) x->Release()


IDirect3D9Ex*               g_D3D9;
IDirect3DDevice9Ex*         g_D3D9Device;
LPD3DXFONT                  g_D3D9Font;

ID3D10Device1*              g_D3D10Device;
ID3D10EffectTechnique*      g_D3D10Technique;
ID3D10EffectMatrixVariable* g_D3D10Matrix;

ISurfaceQueue*				g_ABQueue;
ISurfaceQueue*				g_BAQueue;

struct SimpleVertex
{
    D3DXVECTOR3 Pos;
    D3DXVECTOR2 Tex;
};

SimpleVertex VERTEX_DATA[] =
{
    { D3DXVECTOR3(  0.5f,   0.5f, 0), D3DXVECTOR2(1.0f, 0.0f) },
    { D3DXVECTOR3(  0.5f,  -0.5f, 0), D3DXVECTOR2(1.0f, 1.0f) },
    { D3DXVECTOR3( -0.5f,  -0.5f, 0), D3DXVECTOR2(0.0f, 1.0f) },
	{ D3DXVECTOR3( -0.5f,   0.5f, 0), D3DXVECTOR2(0.0f, 0.0f) },
};

USHORT INDEX_DATA[] = 
{
    0, 1, 2, 0, 2, 3
};

LRESULT CALLBACK WndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam )
{
    PAINTSTRUCT ps;
    HDC hdc;

    switch (message) 
    {
        case WM_PAINT:
            hdc = BeginPaint(hWnd, &ps);
            EndPaint(hWnd, &ps);
            break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}

static INT64 s_TicksPerSecond;
static INT64 s_FPSUpdateInterval;

float UpdateFPS()
{
	static INT64 CurrentTime, LastTime, LastFPSUpdate;
	static UINT NumFrames;
	static float FPS;
    
	QueryPerformanceCounter( (LARGE_INTEGER *)&CurrentTime );

    // Update FPS
    NumFrames++;
    if ( CurrentTime - LastFPSUpdate >= s_FPSUpdateInterval )
    {
        float currentTime = (float)CurrentTime / (float)s_TicksPerSecond;
        float lastTime = (float)LastFPSUpdate / (float)s_TicksPerSecond;
        FPS = (float)NumFrames / (currentTime - lastTime);

        LastFPSUpdate = CurrentTime;
        NumFrames = 0;
    }

    LastTime = CurrentTime; 

    return FPS;
}

HRESULT CreateGeometry(ID3D10Device* pDevice, ID3D10Buffer** ppVertexBuffer, 
        ID3D10Buffer** ppIndexBuffer)
{
    HRESULT hr = S_OK;

    D3D10_BUFFER_DESC bd;
    bd.Usage            = D3D10_USAGE_DEFAULT;
    bd.ByteWidth        = sizeof(VERTEX_DATA);
    bd.BindFlags        = D3D10_BIND_VERTEX_BUFFER;
    bd.CPUAccessFlags   = 0;
    bd.MiscFlags        = 0;
    D3D10_SUBRESOURCE_DATA InitData;
    InitData.pSysMem	= VERTEX_DATA;

    if ( FAILED (hr = pDevice->CreateBuffer(&bd, &InitData, ppVertexBuffer) ) )
    {
        return hr;
    }
    UINT stride = sizeof(SimpleVertex);
    UINT offset = 0;
    pDevice->IASetVertexBuffers(0, 1, ppVertexBuffer, &stride, &offset);

    bd.Usage			= D3D10_USAGE_DEFAULT;
    bd.ByteWidth		= sizeof(INDEX_DATA);
    bd.BindFlags		= D3D10_BIND_INDEX_BUFFER;
    bd.CPUAccessFlags	= 0;
    bd.MiscFlags		= 0;
    InitData.pSysMem	= INDEX_DATA;
    if (FAILED(hr = pDevice->CreateBuffer(&bd, &InitData, ppIndexBuffer)))
    {
        return hr;
    }
    pDevice->IASetIndexBuffer(*ppIndexBuffer, DXGI_FORMAT_R16_UINT, 0);
    pDevice->IASetPrimitiveTopology(D3D10_PRIMITIVE_TOPOLOGY_TRIANGLELIST);

    return hr;
}

HRESULT InitD3D10()
{
    HRESULT hr;
    ID3D10Effect*               pEffect;
    ID3D10InputLayout*          pVertexLayout;
    ID3D10Buffer*               pVertexBuffer;
    ID3D10Buffer*               pIndexBuffer;
    

	UINT		DeviceFlags = 0;
	DWORD		dwShaderFlags = D3D10_SHADER_ENABLE_STRICTNESS;

#ifdef _DEBUG
	DeviceFlags		|= D3D10_CREATE_DEVICE_DEBUG;
	dwShaderFlags	|= D3D10_SHADER_DEBUG;
#endif

    if (FAILED(hr = D3D10CreateDevice1(NULL, D3D10_DRIVER_TYPE_HARDWARE, NULL,
                    DeviceFlags, D3D10_FEATURE_LEVEL_10_0, D3D10_1_SDK_VERSION, &g_D3D10Device)))
    {
        return hr;
    }

    D3D10_VIEWPORT vp;
    vp.Width = WIDTH;
    vp.Height = HEIGHT;
    vp.MinDepth = 0.0f;
    vp.MaxDepth = 1.0f;
    vp.TopLeftX = 0;
    vp.TopLeftY = 0;
    g_D3D10Device->RSSetViewports( 1, &vp );

    // Create the effect
    ID3D10ShaderResourceView*           pTextureRV;
    ID3D10EffectShaderResourceVariable* pTextureVariable;
	if (FAILED(hr = D3DX10CreateShaderResourceViewFromFile(g_D3D10Device, TEXTURE_PATH, NULL, NULL, &pTextureRV, NULL)))
    {
        return hr;
    }
    if (FAILED (hr = D3DX10CreateEffectFromFile( EFFECT_PATH, NULL, NULL, "fx_4_0", dwShaderFlags, 0, 
                    g_D3D10Device, NULL, NULL, &pEffect, NULL, NULL)))
    {
        return hr;
    }
    g_D3D10Technique = pEffect->GetTechniqueByName( "Render" );
    pTextureVariable = pEffect->GetVariableByName( "txDiffuse" ) -> AsShaderResource();

    D3D10_INPUT_ELEMENT_DESC layout[] =
    {
        { "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT, 0, 0, D3D10_INPUT_PER_VERTEX_DATA, 0 },
        { "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT, 0, 12, D3D10_INPUT_PER_VERTEX_DATA, 0 },
    };
    UINT numElements = sizeof(layout) / sizeof(layout[0]);

    D3D10_PASS_DESC PassDesc;
    g_D3D10Technique->GetPassByIndex(0)->GetDesc(&PassDesc);
    if (FAILED (hr = g_D3D10Device->CreateInputLayout( layout, numElements, PassDesc.pIAInputSignature,
                    PassDesc.IAInputSignatureSize, &pVertexLayout) ) )
    {
        return hr;
    }
    g_D3D10Device->IASetInputLayout(pVertexLayout);
    pTextureVariable->SetResource(pTextureRV);

    g_D3D10Matrix = pEffect->GetVariableByName("WorldMatrix")->AsMatrix();

    /* Create the geometry */
    if (FAILED(hr = CreateGeometry(g_D3D10Device, &pVertexBuffer, &pIndexBuffer)))
    {
        return hr;
    }

	D3D10_RASTERIZER_DESC rasterizerState;
	ZeroMemory(&rasterizerState, sizeof(D3D10_RASTERIZER_DESC));
    rasterizerState.CullMode				= D3D10_CULL_NONE;
    rasterizerState.FillMode				= D3D10_FILL_SOLID;


    ID3D10RasterizerState* pRS;
    g_D3D10Device->CreateRasterizerState( &rasterizerState, &pRS);
    g_D3D10Device->RSSetState(pRS);

    return S_OK;
}

void CleanupD3D10()
{
	SAFE_RELEASE(g_D3D10Device);
}

void RenderD3D10(int count)
{
    float angle = (count / 200.0f);
    D3DXMATRIX matrix;
    D3DXMatrixIdentity(&matrix);
    D3DXMatrixRotationY(&matrix, angle);
    g_D3D10Matrix->SetMatrix( (float*) &matrix);

    D3D10_TECHNIQUE_DESC techDesc;
    g_D3D10Technique->GetDesc(&techDesc);
    for (UINT p = 0; p < techDesc.Passes; ++p)
    {
        g_D3D10Technique->GetPassByIndex(p)->Apply( 0 );
		g_D3D10Device->DrawIndexed(ARRAYSIZE(INDEX_DATA), 0, 0);
    }
}

HRESULT InitD3D9(HWND hWnd)
{
    HRESULT hr;
    Direct3DCreate9Ex( D3D_SDK_VERSION, &g_D3D9 );
    if (!g_D3D9)
	{
		return E_FAIL;
	}

    D3DPRESENT_PARAMETERS		d3dpp;
    ZeroMemory( &d3dpp, sizeof(d3dpp) );
    d3dpp.Windowed				= TRUE;
    d3dpp.SwapEffect			= D3DSWAPEFFECT_DISCARD;
    d3dpp.hDeviceWindow			= hWnd;
    d3dpp.PresentationInterval	= D3DPRESENT_INTERVAL_IMMEDIATE;

    hr = g_D3D9->CreateDeviceEx(
            D3DADAPTER_DEFAULT,
            D3DDEVTYPE_HAL,
            hWnd,
            D3DCREATE_HARDWARE_VERTEXPROCESSING,
            &d3dpp,
            NULL,
            &g_D3D9Device);

    if (FAILED(hr))
    {
        return hr;
    }

    hr = D3DXCreateFont(g_D3D9Device, -15, 0, 0, 1, false, DEFAULT_CHARSET,
                        OUT_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE,
                        "Arial", &g_D3D9Font);
    return hr;
}

void CleanupD3D9()
{
	SAFE_RELEASE(g_D3D9Font);
	SAFE_RELEASE(g_D3D9Device);
	SAFE_RELEASE(g_D3D9);
}

HRESULT RenderD3D9()
{
    HRESULT hr = E_FAIL;

    RECT rect = {0, 0, 200, 15};
    
    if (FAILED(hr = g_D3D9Device->BeginScene()))
    {
        return hr;
    }

    float FPS = UpdateFPS();

    char fpsBuffer[1024];
    sprintf_s(fpsBuffer, 1024, "FPS: %.2f", FPS);
    g_D3D9Font->DrawText(NULL, fpsBuffer, -1, &rect, 0, D3DCOLOR_XRGB(255, 255, 255));
   
    rect.top = 15; 
    rect.bottom = 30;
    sprintf_s(fpsBuffer, 1024, "Render time: %.2f ms", 1000.0f / FPS);
    g_D3D9Font->DrawText(NULL, fpsBuffer, -1, &rect, 0, D3DCOLOR_XRGB(255, 255, 255));

	hr = g_D3D9Device->EndScene();

    return hr;
}

HRESULT InitD3D(HWND hWnd)
{
    HRESULT hr;
    if (FAILED(hr = InitD3D9(hWnd)))
    {
        return hr;
    }

    if (FAILED(hr = InitD3D10()))
    {
        return hr;
    }

    // 
    // Initialize the surface queues
    //
    SURFACE_QUEUE_DESC  desc    = {0};
    desc.Width                  = WIDTH;
    desc.Height                 = HEIGHT;
    desc.Format                 = DXGI_FORMAT_B8G8R8A8_UNORM;
    desc.NumSurfaces            = 3;
    desc.MetaDataSize           = sizeof(int);
    desc.Flags                  = SURFACE_QUEUE_FLAG_SINGLE_THREADED;

    if (FAILED(hr = CreateSurfaceQueue(&desc, g_D3D9Device, &g_ABQueue)))
    {
        return hr;
    }

    // Clone the queue
    SURFACE_QUEUE_CLONE_DESC CloneDesc = {0};
    CloneDesc.MetaDataSize      = 0;
    CloneDesc.Flags             = SURFACE_QUEUE_FLAG_SINGLE_THREADED;
    if (FAILED(hr = g_ABQueue->Clone(&CloneDesc, &g_BAQueue)))
    {
        return hr;
    }
    return hr;
}


void CleanupD3D()
{
	SAFE_RELEASE(g_ABQueue);
	SAFE_RELEASE(g_BAQueue);
    CleanupD3D10();
    CleanupD3D9();
}

void Start()
{
    HRESULT hr;

    ISurfaceConsumer*		ABConsumer = NULL;
    ISurfaceProducer*		BAProducer = NULL;
    ISurfaceConsumer*		BAConsumer = NULL;
    ISurfaceProducer*		ABProducer = NULL;

    ID3D10Texture2D*        pSurface10;
    REFIID                  surfaceID10 = __uuidof(ID3D10Texture2D);
    IDirect3DTexture9*      pTexture9;
    REFIID                  surfaceID9 = __uuidof(IDirect3DTexture9);


    IDirect3DSurface9*      pSurface9;
    IDirect3DSurface9*      pBackSurface;
    ID3D10RenderTargetView* pRenderTargetView = NULL;  
   
    MSG msg = {0};
    float ClearColor[4] = { 0, .15f, .4f, 1};

	if (FAILED(hr = g_BAQueue->OpenProducer(g_D3D10Device, &BAProducer)))
    {
		goto end;
    }

    if (FAILED(hr = g_ABQueue->OpenConsumer(g_D3D10Device, &ABConsumer)))
    {
		goto end;
    }

    if (FAILED(hr = g_ABQueue->OpenProducer(g_D3D9Device, &ABProducer)))
    {
        goto end;
    }

    if (FAILED(hr = g_BAQueue->OpenConsumer(g_D3D9Device, &BAConsumer)))
    {
		goto end;
    }

    while( WM_QUIT != msg.message)
    {
        if( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) )
        {
            TranslateMessage( &msg );
            DispatchMessage( &msg );
        }
        else
        {
            pSurface10 = NULL;
            pSurface9  = NULL;

            // D3D10 portion
            {
                int count = 0;
                UINT size = sizeof(int);

                // Dequeue from AB queue
                hr = ABConsumer->Dequeue(surfaceID10, (void**)&pSurface10, &count, &size, 0);
                if (SUCCEEDED(hr))
                {
                    // there's a surface ready to use

                    g_D3D10Device->CreateRenderTargetView(pSurface10, NULL, &pRenderTargetView);
                    g_D3D10Device->OMSetRenderTargets(1, &pRenderTargetView, NULL);

                    g_D3D10Device->ClearRenderTargetView(pRenderTargetView, ClearColor);

                    // Render D3D10 content
                    RenderD3D10(count);

					g_D3D10Device->OMSetRenderTargets(0, 0, 0);
					pRenderTargetView->Release();

					// Produce the surface
                    BAProducer->Enqueue(pSurface10, NULL, NULL, SURFACE_QUEUE_FLAG_DO_NOT_WAIT);
                    pSurface10->Release();                    
                }
            }


            // D3D9 Portion
            {
                static int count = 0;

                // Dequeue from BA queue
                hr = BAConsumer->Dequeue(surfaceID9, (void**)&pTexture9, NULL, NULL, 0);
                if (SUCCEEDED(hr))
                {
                    // Get the top level surface from the texture
                    pTexture9->GetSurfaceLevel(0, &pSurface9);

                    // Set up render target on d3d9
                    g_D3D9Device->GetRenderTarget(0, &pBackSurface);
                    g_D3D9Device->SetRenderTarget(0, pSurface9);

                    // Render d3d9 content
                    RenderD3D9();

                    // Present with D3D9
                    g_D3D9Device->SetRenderTarget(0, pBackSurface);
                    g_D3D9Device->StretchRect(pSurface9, NULL, pBackSurface, NULL, D3DTEXF_NONE);
                    g_D3D9Device->Present(NULL, NULL, NULL, NULL);

                    pBackSurface->Release();
                    pSurface9->Release();
					
                    // Produce Surface
                    ABProducer->Enqueue(pTexture9, &count, sizeof(int), SURFACE_QUEUE_FLAG_DO_NOT_WAIT);
                    pTexture9->Release();

                    count++;
                }
            }


            // Flush the AB queue
            BAProducer->Flush(SURFACE_QUEUE_FLAG_DO_NOT_WAIT, NULL);
            // Flush the BA queue
            ABProducer->Flush(SURFACE_QUEUE_FLAG_DO_NOT_WAIT, NULL);
        }
    }

end:
	SAFE_RELEASE(BAProducer);
	SAFE_RELEASE(ABProducer);
	SAFE_RELEASE(BAConsumer);
	SAFE_RELEASE(ABConsumer);

}

extern "C" int WINAPI WinMain
(
 HINSTANCE hInstance,
 HINSTANCE ,
 LPTSTR    ,
 int       )
{
	
	// Setup the FPS counter
    QueryPerformanceFrequency( (LARGE_INTEGER *)&s_TicksPerSecond );
    s_FPSUpdateInterval = s_TicksPerSecond >> 1; 

    // Register class
    WNDCLASSEX wcex;
    wcex.cbSize         = sizeof(WNDCLASSEX); 
    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, (LPCTSTR)"Sample");
    wcex.hCursor        = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = NULL;
    wcex.lpszClassName  = "D3DSample";
    wcex.hIconSm        = LoadIcon(wcex.hInstance, (LPCTSTR)"Sample");
    
	RegisterClassEx(&wcex);

	RECT rc = { 0, 0, WIDTH, HEIGHT };
    AdjustWindowRect( &rc, WS_OVERLAPPEDWINDOW, FALSE );
    HWND hWnd = CreateWindow(	"D3DSample", "D3D9/D3D10 Interop Sample", 
								WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, 
								CW_USEDEFAULT, 
								rc.right - rc.left, rc.bottom - rc.top, 
								NULL, NULL, hInstance, NULL);
	if (hWnd)
	{
		if (SUCCEEDED(InitD3D(hWnd)))
		{
			ShowWindow(hWnd, TRUE);
			Start();
			CleanupD3D();
			goto success;
		}
	}
	
	return 1;

success:
    return 0;
}



